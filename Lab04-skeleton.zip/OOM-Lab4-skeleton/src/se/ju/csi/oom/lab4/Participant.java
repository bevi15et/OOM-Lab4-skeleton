package se.ju.csi.oom.lab4;

public interface Participant {

	public String getName();
	public void setName(String name);
	
	public String getIdNr();
	public void setIdNr(String idNr);
}
